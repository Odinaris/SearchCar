package me.odinaris.searchcar.bean

class CarIntro(
        var name: String,
        var imageUrl: String,
        var registerTime: String,
        var mileAge: String,
        var price: String,
        var newPrice: String,
        var objectId: String)





