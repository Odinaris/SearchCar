package me.odinaris.searchcar.bean


import cn.bmob.v3.BmobUser
import me.odinaris.searchcar.login.LoginActivity

/**
 * Created by Odinaris on 2017/3/14.
 */
class userInfo : BmobUser() {
    var userId: String = ""
}